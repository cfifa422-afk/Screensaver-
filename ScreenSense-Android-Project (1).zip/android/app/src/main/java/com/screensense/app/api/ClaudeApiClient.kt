package com.screensense.app.api

import com.google.gson.Gson
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.sse.*
import java.util.concurrent.TimeUnit

class ClaudeApiClient(
    private val apiKeyProvider: () -> String
) {
    companion object {
        const val ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
        const val ANTHROPIC_VERSION = "2023-06-01"

        const val SYSTEM_PROMPT =
            "You are ScreenSense, a versatile floating on-screen assistant and brainstorming companion. You appear as an overlay on top of any app on Android. Dual Capabilities: 1) Screen Vision: When provided with a screenshot, understand the UI, text, code, receipts, or images, answering questions grounded in that visual context. 2) Free Chat & Brainstorming: When asked general questions, to brainstorm ideas, write drafts, solve code, or explore creative thoughts, act as a top-tier brainstorming partner. Keep answers concise by default (1-4 sentences), or structured with clear bullet points when brainstorming. Output plain conversational text."
    }

    private val gson = Gson()
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun streamScreenAnalysis(imageBase64: String?, userQuestion: String?): Flow<String> = callbackFlow {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isEmpty()) {
            trySend("Error: Anthropic API key is not configured. Please set sk-ant-... in ScreenSense Settings.")
            close()
            return@callbackFlow
        }

        val promptText = if (userQuestion.isNullOrBlank()) {
            "Please analyze the current screen. Summarize what is shown, highlight key details, or suggest relevant actions."
        } else userQuestion.trim()

        val contentBlocks = mutableListOf<ContentBlock>()
        if (!imageBase64.isNullOrBlank()) {
            contentBlocks.add(ContentBlock.Image(source = ImageSource(data = imageBase64)))
        }
        contentBlocks.add(ContentBlock.Text(text = promptText))

        val requestPayload = AnthropicMessageRequest(
            model = "claude-3-5-sonnet-20241022",
            maxTokens = 800,
            system = SYSTEM_PROMPT,
            messages = listOf(
                MessageItem(
                    role = "user",
                    content = contentBlocks
                )
            ),
            stream = true
        )

        val request = Request.Builder()
            .url(ANTHROPIC_API_URL)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", ANTHROPIC_VERSION)
            .addHeader("content-type", "application/json")
            .post(gson.toJson(requestPayload).toRequestBody("application/json".toMediaType()))
            .build()

        val eventSourceListener = object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "[DONE]") {
                    channel.close()
                    return
                }
                try {
                    val deltaEvent = gson.fromJson(data, StreamDeltaEvent::class.java)
                    if (deltaEvent.type == "content_block_delta" && deltaEvent.delta?.text != null) {
                        trySend(deltaEvent.delta.text)
                    } else if (deltaEvent.type == "message_stop") {
                        channel.close()
                    }
                } catch (e: Exception) {}
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                trySend("
[Stream error: ${response?.message ?: t?.localizedMessage}]")
                channel.close(t)
            }

            override fun onClosed(eventSource: EventSource) {
                channel.close()
            }
        }

        val eventSource = EventSources.createFactory(okHttpClient).newEventSource(request, eventSourceListener)
        awaitClose { eventSource.cancel() }
    }
}