package com.screensense.app.capture

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val backgroundHandler = Handler(Looper.getMainLooper())

    val isPermissionGranted: Boolean get() = mediaProjection != null

    fun setMediaProjection(projection: MediaProjection) {
        this.mediaProjection = projection
    }

    suspend fun captureScreenBase64(): Result<String> = suspendCancellableCoroutine { continuation ->
        val projection = mediaProjection ?: run {
            continuation.resume(Result.failure(IllegalStateException("MediaProjection permission not granted yet")))
            return@suspendCancellableCoroutine
        }

        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels
        val densityDpi = metrics.densityDpi

        imageReader?.close()
        virtualDisplay?.release()

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        this.imageReader = reader

        var imageCaptured = false

        reader.setOnImageAvailableListener({ ir ->
            if (imageCaptured) return@setOnImageAvailableListener
            var image: Image? = null
            try {
                image = ir.acquireLatestImage()
                if (image != null) {
                    imageCaptured = true
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * screenWidth

                    val rawBitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride, screenHeight, Bitmap.Config.ARGB_8888
                    )
                    rawBitmap.copyPixelsFromBuffer(buffer)

                    val croppedBitmap = if (rowPadding > 0) {
                        Bitmap.createBitmap(rawBitmap, 0, 0, screenWidth, screenHeight)
                    } else rawBitmap

                    // Downscale to max 1024px on long edge
                    val downscaledBitmap = downscaleBitmap(croppedBitmap, 1024)

                    val outputStream = ByteArrayOutputStream()
                    downscaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
                    val base64String = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

                    if (croppedBitmap != rawBitmap) rawBitmap.recycle()
                    if (downscaledBitmap != croppedBitmap) croppedBitmap.recycle()
                    downscaledBitmap.recycle()

                    cleanupDisplay()
                    if (continuation.isActive) continuation.resume(Result.success(base64String))
                }
            } catch (e: Exception) {
                cleanupDisplay()
                if (continuation.isActive) continuation.resume(Result.failure(e))
            } finally {
                image?.close()
            }
        }, backgroundHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "ScreenSenseCapture", screenWidth, screenHeight, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, backgroundHandler
        )
    }

    private fun downscaleBitmap(source: Bitmap, maxLongEdge: Int): Bitmap {
        val width = source.width
        val height = source.height
        val longEdge = max(width, height)
        if (longEdge <= maxLongEdge) return source
        val scaleRatio = maxLongEdge.toFloat() / longEdge.toFloat()
        return Bitmap.createScaledBitmap(source, (width * scaleRatio).roundToInt(), (height * scaleRatio).roundToInt(), true)
    }

    private fun cleanupDisplay() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
    }

    fun release() {
        cleanupDisplay()
        mediaProjection?.stop()
        mediaProjection = null
    }
}