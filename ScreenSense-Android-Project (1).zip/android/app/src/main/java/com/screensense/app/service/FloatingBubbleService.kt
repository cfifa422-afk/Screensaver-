package com.screensense.app.service

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.screensense.app.R
import com.screensense.app.ScreenSenseApp
import com.screensense.app.api.ClaudeApiClient
import com.screensense.app.capture.MediaProjectionTrampolineActivity
import com.screensense.app.capture.ScreenCaptureManager
import com.screensense.app.data.SettingsRepository
import com.screensense.app.ui.onboarding.OnboardingActivity
import com.screensense.app.ui.overlay.BubblePhysics
import com.screensense.app.ui.overlay.ScreenSenseOverlay
import com.screensense.app.ui.overlay.SpeechInputManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class FloatingBubbleService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_MEDIA_PROJECTION_RESULT = "ACTION_MEDIA_PROJECTION_RESULT"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var streamingJob: Job? = null

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: ComposeView
    private lateinit var windowLayoutParams: WindowManager.LayoutParams

    private lateinit var captureManager: ScreenCaptureManager
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var claudeClient: ClaudeApiClient
    private lateinit var speechManager: SpeechInputManager

    // UI state observable by ComposeView
    private val isExpanded = mutableStateOf(false)
    private val isScanning = mutableStateOf(false)
    private val isStreaming = mutableStateOf(false)
    private val analysisText = mutableStateOf("")
    private val bubbleOpacity = mutableFloatStateOf(0.9f)
    private val isVoiceListening = mutableStateOf(false)

    private var lastCapturedImageBase64: String? = null
    private var screenWidth = 1080
    private var screenHeight = 2400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        captureManager = ScreenCaptureManager(this)
        settingsRepo = SettingsRepository(this)
        speechManager = SpeechInputManager(this)

        claudeClient = ClaudeApiClient {
            runBlocking { settingsRepo.anthropicApiKey.first() }
        }

        updateScreenMetrics()
        startForegroundServiceWithNotification()
        setupOverlayView()
        observeSettings()
    }

    private fun updateScreenMetrics() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    private fun startForegroundServiceWithNotification() {
        val openAppIntent = Intent(this, OnboardingActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, ScreenSenseApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("ScreenSense is active")
            .setContentText("Tap the floating bubble anytime to analyze on-screen content.")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(ScreenSenseApp.NOTIFICATION_ID, notification)
    }

    private fun setupOverlayView() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - 180
            y = screenHeight / 3
        }

        overlayView = ComposeView(this).apply {
            val lifecycleOwner = OverlayLifecycleOwner()
            lifecycleOwner.performRestore(null)
            lifecycleOwner.handleLifecycleEvent(androidx.lifecycle.Lifecycle.Event.ON_CREATE)
            lifecycleOwner.handleLifecycleEvent(androidx.lifecycle.Lifecycle.Event.ON_START)
            lifecycleOwner.handleLifecycleEvent(androidx.lifecycle.Lifecycle.Event.ON_RESUME)

            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                ScreenSenseOverlay(
                    isExpanded = isExpanded.value,
                    isScanning = isScanning.value,
                    isStreaming = isStreaming.value,
                    analysisText = analysisText.value,
                    bubbleOpacity = bubbleOpacity.floatValue,
                    onBubbleTap = { handleBubbleTap() },
                    onDragDelta = { dx, dy -> handleDrag(dx, dy) },
                    onDragEnd = { snapToNearestEdge() },
                    onClosePanel = { collapsePanel() },
                    onReCapture = { triggerScreenCapture(null) },
                    onSubmitQuestion = { question -> handleUserQuestion(question) },
                    onStartVoiceInput = { handleVoiceInput() },
                    isVoiceListening = isVoiceListening.value
                )
            }
        }

        windowManager.addView(overlayView, windowLayoutParams)
    }

    private fun handleBubbleTap() {
        if (!isExpanded.value) {
            expandPanel()
            if (!captureManager.isPermissionGranted) {
                MediaProjectionTrampolineActivity.start(this)
            } else {
                triggerScreenCapture(null)
            }
        } else {
            collapsePanel()
        }
    }

    private fun expandPanel() {
        isExpanded.value = true
        windowLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        windowManager.updateViewLayout(overlayView, windowLayoutParams)
    }

    private fun collapsePanel() {
        isExpanded.value = false
        windowLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        windowManager.updateViewLayout(overlayView, windowLayoutParams)
        speechManager.stopListening()
    }

    private fun snapToNearestEdge() {
        val targetX = BubblePhysics.calculateSnapX(
            currentX = windowLayoutParams.x.toFloat(),
            screenWidth = screenWidth,
            bubbleWidth = 160
        ).toInt()

        val startX = windowLayoutParams.x
        ValueAnimator.ofInt(startX, targetX).apply {
            duration = 240
            interpolator = android.view.animation.OvershootInterpolator(0.8f)
            addUpdateListener { animator ->
                windowLayoutParams.x = animator.animatedValue as Int
                windowManager.updateViewLayout(overlayView, windowLayoutParams)
            }
            start()
        }
    }

    private fun triggerScreenCapture(userQuestion: String?) {
        serviceScope.launch {
            isScanning.value = true
            analysisText.value = ""

            overlayView.visibility = android.view.View.INVISIBLE
            delay(100)

            val captureResult = captureManager.captureScreenBase64()
            overlayView.visibility = android.view.View.VISIBLE
            isScanning.value = false

            captureResult.onSuccess { base64Image ->
                lastCapturedImageBase64 = base64Image
                streamClaudeResponse(base64Image, userQuestion)
            }.onFailure { error ->
                analysisText.value = "Unable to capture screen: ${error.localizedMessage}. Please verify screen capture permissions."
            }
        }
    }

    private fun streamClaudeResponse(base64Image: String, question: String?) {
        streamingJob?.cancel()
        streamingJob = serviceScope.launch {
            isStreaming.value = true
            analysisText.value = ""

            claudeClient.streamScreenAnalysis(base64Image, question).collect { token ->
                analysisText.value += token
            }
            isStreaming.value = false
        }
    }
}