package com.screensense.app.ui.overlay

import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun ScreenSenseOverlay(
    isExpanded: Boolean,
    isScanning: Boolean,
    isStreaming: Boolean,
    analysisText: String,
    bubbleOpacity: Float,
    onBubbleTap: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit,
    onDragEnd: () -> Unit,
    onClosePanel: () -> Unit,
    onReCapture: () -> Unit,
    onSubmitQuestion: (String) -> Unit,
    onStartVoiceInput: () -> Unit,
    isVoiceListening: Boolean = false,
    modifier: Modifier = Modifier
) {
    var questionInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    LaunchedEffect(analysisText) {
        if (analysisText.isNotEmpty()) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    Box(modifier = modifier) {
        if (!isExpanded) {
            CollapsedBubble(
                opacity = bubbleOpacity,
                onTap = onBubbleTap,
                onDragDelta = onDragDelta,
                onDragEnd = onDragEnd
            )
        } else {
            ExpandedPanel(
                isScanning = isScanning,
                isStreaming = isStreaming,
                analysisText = analysisText,
                questionInput = questionInput,
                onQuestionChange = { questionInput = it },
                onClose = onClosePanel,
                onReCapture = onReCapture,
                onSubmit = {
                    if (questionInput.isNotBlank()) {
                        onSubmitQuestion(questionInput)
                        questionInput = ""
                    }
                },
                onVoiceInput = onStartVoiceInput,
                isVoiceListening = isVoiceListening,
                scrollState = scrollState
            )
        }
    }
}

@Composable
fun CollapsedBubble(
    opacity: Float,
    onTap: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit,
    onDragEnd: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "IdleFloat")
    val idleYOffset by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "FloatY"
    )

    Box(
        modifier = Modifier
            .offset { IntOffset(0, idleYOffset.roundToInt()) }
            .size(56.dp)
            .shadow(
                elevation = 24.dp,
                shape = CircleShape,
                ambientColor = Color.Black.copy(alpha = 0.35f),
                spotColor = Color.Black.copy(alpha = 0.35f)
            )
            .then(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Modifier.blur(24.dp)
                } else Modifier
            )
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFFA855F7).copy(alpha = 0.38f * opacity),
                        Color.White.copy(alpha = 0.35f * opacity),
                        Color(0xFFC084FC).copy(alpha = 0.42f * opacity)
                    )
                ),
                CircleShape
            )
            .border(1.5.dp, Color.White.copy(alpha = 0.70f * opacity), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    },
                    onDragEnd = { onDragEnd() }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onTap() })
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.AutoAwesome,
            contentDescription = "ScreenSense",
            modifier = Modifier.size(26.dp),
            tint = Color.White.copy(alpha = 0.85f * opacity)
        )
    }
}