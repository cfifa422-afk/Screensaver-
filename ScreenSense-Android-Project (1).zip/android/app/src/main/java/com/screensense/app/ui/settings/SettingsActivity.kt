package com.screensense.app.ui.settings

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.screensense.app.data.SettingsRepository

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = SettingsRepository(this)
        setContent {
            MaterialTheme {
                SettingsScreen(
                    repository = repo,
                    onBack = { finish() }
                )
            }
        }
    }
}